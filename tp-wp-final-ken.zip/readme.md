# Travail pratique 1
## Développement d’une extension et amélioration d’un thème

Accéder au Site web: 
[SiteGround](https://eddym91.sg-host.com/)

Pour plus d'information sur la conception de thème
[wp developper guide](https://developer.wordpress.org/)