<footer class="site__footer">
    <div class="footer_menu">
       <a href="">kenneth Edwin Gbeti</a>
    </div>
</footer>
<?php wp_footer(); ?>
</section> <!-- fin .site -->
</body>
</html>